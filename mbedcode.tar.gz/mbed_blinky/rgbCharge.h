#ifndef RGBCHARGE_H
#define RGBCHARGE_H

class rgbCharge
{
    //color judgment(int r, int g, int b);
public:
    rgbCharge();
    int FindColor(int r, int g, int b);
    int FindColorBeta(int r, int g, int b);
    // Read the data from current color array
    void ReadInData(int number, int r, int g, int b);
    // Read and store the data of the map, the correct data
    void GetMapData(int number, int r, int g, int b, int value, int mapnumber);
    // judgement
    bool Decide(int mapnumber);
    
private:
    int (*_MapData)[4];
    int _resultarray[8][3];
    int _size;
    int _mapnumber;
    void ArrayResize(int newsize);
};
    

#endif