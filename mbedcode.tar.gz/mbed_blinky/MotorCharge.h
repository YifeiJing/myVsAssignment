#ifndef MOTORCHARGE_H
#define MOTORCHARGE_H

class MotorCharge {
    public:
        MotorCharge(PinName s1, PinName s2);
        void LeftOn();
        void RightOn();
        void StraightOn();
        void Stop();
    private:
        DigitalOut Left,Right;
};

#endif