#include "mbed.h"
#include "MotorCharge.h"

MotorCharge::MotorCharge(PinName s1, PinName s2):Left(s1,0),Right(s2,0)
{}

void MotorCharge::LeftOn()
{
    Left = 0;
    Right = 1;
}
void MotorCharge::RightOn()
{
    Left = 1;
    Right = 0;
}
void MotorCharge::StraightOn()
{
    Left = 1;
    Right = 1;
}
void MotorCharge::Stop()
{
    Left = 0;
    Right = 0;
}