#ifndef MAPDATA_H
#define MAPDATA_H

int Map01[8] = {0,0,0,1,3,3,3,0};

#endif