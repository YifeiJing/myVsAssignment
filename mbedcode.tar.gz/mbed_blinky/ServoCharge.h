#ifndef SERVOCHARGE_H
#define SERVOCHARGE_H
#include "mbed.h"

class ServoCharge {
public:
    ServoCharge(PinName s1, PinName s2, PinName s3);
    void Turn_0();
    void Turn_45();
    void Turn_90();
    void Turn_60();
    void Turn_120();
    void Turn_150();
    void Turn_180();
    void Turn_30();
private:
    DigitalOut sel_1,sel_2,sel_3;
};

#endif