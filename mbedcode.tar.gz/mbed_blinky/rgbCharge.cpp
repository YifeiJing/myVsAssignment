#include "rgbCharge.h"

rgbCharge::rgbCharge()
{
    _MapData = new int[8][4];
    _mapnumber = 1;
    _size = 8;
}

///
/// The function to judge color: red, green, blue
///
int rgbCharge::FindColor(int r, int g, int b)
{
    //rgbCharge::color Color;
    int red = r*255/(r+g+b);
    int green = g*255/(r+g+b);
    int blue = b*255/(r+g+b);
    if(red > green && red > blue)
    {
        return 1;
    }
    else if(red < green && green > blue)
    {
        return 2;
    }
    else if(red< blue && green < blue)
    {
        return 3;
    }
    else if(red == blue && red == green)
    {
        return 0;
    }
    else if(red == 0 || blue == 0 || green == 0)
    {
        return 0;
    }
    else
    {
        return 1;
    }
    
}

int rgbCharge::FindColorBeta(int r, int g, int b)
{
    int red = r*255/(r+g+b);
    int green = g*255/(r+g+b);
    int blue = b*255/(r+g+b);
    if(red >= 89 && red <= 110 && blue >= 74 && blue <= 94)
        return 1;
    else if(red >= 40 && red <= 77 && blue <= 140 && blue >= 108)
        return 3;
    else if(red >= 60 && red <= 88 && green >= 70 && green <= 90 && blue <= 108 && blue >= 85)
        return 0;
    else
        return 2;
}

void rgbCharge::ReadInData(int number, int r, int g, int b)
{
    _resultarray[number][0] = r;
    _resultarray[number][1] = g;
    _resultarray[number][2] = b; 
    
}

void rgbCharge::GetMapData(int number, int r, int g, int b, int value, int mapnumber)
{
    if(mapnumber * 8 > _size) ArrayResize(mapnumber * 8);
    
    int temp = mapnumber - 1;
    
    _MapData[temp * 8 + number][0] = r;
    _MapData[temp * 8 + number][1] = g;
    _MapData[temp * 8 + number][2] = b;
    _MapData[temp * 8 + number][3] = value;
    
}

bool rgbCharge::Decide(int mapnumber)
{
    int temp = mapnumber - 1;
    
    for(int i = 0; i != 8; i++)
    {
        if(_resultarray[i][0] >= _MapData[temp * 8 + i][0] - 9 && 
            _resultarray[i][0] <= _MapData[temp * 8 + i][0] + 9 &&
            _resultarray[i][1] >= _MapData[temp * 8 + i][1] - 9 &&
            _resultarray[i][1] <= _MapData[temp * 8 + i][1] + 9 &&
            _resultarray[i][2] >= _MapData[temp * 8 + i][2] - 9 &&
            _resultarray[i][2] <= _MapData[temp * 8 + i][2] + 9)
            continue;
        else
            return false;
    }
    
    return true;
    
}

void rgbCharge::ArrayResize(int newsize)
{
    int (*p)[4] = new int[newsize * 8][4];
    
    for(int i = 0; i != _mapnumber; i++)
    {
        for(int j = 0; j != 8; j++)
        {
            *(*(p + i * 8 + j) + 0) = *(*(_MapData + i * 8 + j) + 0);
            *(*(p + i * 8 + j) + 1) = *(*(_MapData + i * 8 + j) + 1);
            *(*(p + i * 8 + j) + 2) = *(*(_MapData + i * 8 + j) + 2);
            *(*(p + i * 8 + j) + 3) = *(*(_MapData + i * 8 + j) + 3);
        }
    }
    
    _mapnumber = newsize / 8;
    _size = newsize;
}