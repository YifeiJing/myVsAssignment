#include "mbed.h"
#include "TCS3472_I2C.h"
#include "Funcs.h"
#include "ServoCharge.h"
#include "rgbCharge.h"
#include "HCSR04.h"
#include "MotorCharge.h"
#include "MapData.h"
#include "VL6180.h"

///
/// Instantiations
///

#define VL6180X_ADDRESS 0x29

// (tri,eco)
HCSR04 UltralSonicLeft(p21,p22);
HCSR04 UltralSonicRight(p24,p25);
DigitalIn Xred(p23);
DigitalIn OpticGate(p16);
InterruptIn Magnetss(p12);

// rgb sensor (sda,scl)
TCS3472_I2C colorsensor(p28, p27);
TCS3472_I2C colorsensor2(p9, p10);

// distance sensor (sda,scl)
//VL6180x rf(p28, p27, VL6180X_ADDRESS << 1);
VL6180 rf(p28, p27);

// Servo connect to fpga
ServoCharge servo(p5, p6, p7);
DigitalOut ServoSelect1(p8,0);
DigitalOut ServoSelect0(p11,0);

// Serial port
Serial myPort(USBTX,USBRX,9600);

// rgb helper function
rgbCharge rgbcharge;

// Motors at the bottom
MotorCharge motorCharge(p19,p18);

// Control the motors
// The motor on the top
DigitalOut Charge0(p20);
DigitalOut Charge1(p15);
// The motor control the box in the middle part
DigitalOut Charge2(p17);
DigitalOut Charge3(p13);

// Observe the condiction of the upper box
DigitalIn Detector(p29);

// The light of the gate
DigitalOut GateLight(p14);

//The command buffer
char buffer[5];
//Card verify array
int verifyarray[4];
// Map array
int maparray[8];
// The data of the map, the correct data
// It will compare to maparray later
int correctarray[8];
// RGB results buffers
int rgb_readings[4];
int rgb_readings2[4];
// Ultralsonic distance data array
long UltralArray[2];
//Game control
int mapnumber;
bool IsPlaying = false;
bool FindingUser = true;
bool IsVerifying = false;
bool IsStaring = false;
bool IsStaringLeft = false;
bool IsStaringRight = false;
bool IsTest = true;
bool IsCardIn = false;
bool IsFetched = false;
bool IsEscape = false;

//Main
int main() {
        myPort.attach(&CommandReceive);
        Magnetss.rise(&GameComplete);
        //TouchUser();
        Initrgbs();
        __disable_irq();
        
        /* Game logics */
        char a = myPort.getc();
        
        GameLogicControl();
        /* *********** */
        
        //doumo();
        //MotorFunc2();
        /*while(1)
        {
            if(ReadXred())
            {
                //myPort.printf("human detect\n");
                humandetect = 1;
            }
           
            wait(0.5);
        }*/
        //char a = myPort.getc();
        //FindUser();
        /*while(1)
        {
            //wait(1);
        UltalDistance();
        }*/
        
        /*
        rf.VL6180xDefautSettings(); //Load default settings to get started.
  
        wait_ms(1000);
        
        while(1)
        {
            myPort.printf("Distance: %d\n", rf.getDistance());
            wait(1);
        }*/
        /*while(1)
        {
            distancesensorfunc();
            wait(1);
        }*/
}

//Start menu
void doumo()
{
    myPort.printf("Enter \"?\" to show command list\n");
    bool IsOver = false;
    while(!IsOver)
    {
    char a = myPort.getc();
    switch(a)
    {
        case 'r': rgbsensorfunc(); break;
        case 's': distancesensorfunc(); break;
        case '?': helperfunc(); break;
        case 'm': fpgafunc(); break;
        case 'k': SelectServo(); break;
        case 'g': GetGate(); break;
        case 'p': MotorFunc(); break;
        case 'd': UltalDistance(); break;
        case 'y': GetResult(); break;
        case 'u': printTheArray(); break;
        case 'a': Gift(); break;
        case 'c': ControlTheMidMotor(); break;
        case 'e': ControlTheMotor(); break;
        case 'b': ReadDetector(); break;
        case 'q': QuitDoumo(IsOver); break;
        case 'l': LightCharge(); break;
        case 'f': GetCardInformation(); break;
        case 'h': printCardInfo(); break;
        case 't': FuncControlTheMidMotor(); break;
        case 'i': FuncControlTheMotor(); break;
        case 'o': InitializergbData(); break;
        case 'z': GetResultBeta(); break;
        case 'x': GetTheDecide(); break;
        case 'v': FuncTopMotorUpSlow(); break;
        default: myPort.printf("Invalid command, enter \"?\" to see command list\n"); break;
    }
    }
}

void GameComplete()
{
    //Magnetss.disable_irq();
    wait(0.2);
    if(Magnetss == 1)
        IsPlaying = false;
    //Magnetss.enable_irq();
}

void printCardInfo()
{
    for(int i = 0; i != 4; i++)
    myPort.printf("%d\n",verifyarray[i]);
}

void QuitDoumo(bool &IsOver)
{
    IsOver = true;
    TurnToFirst();
    wait(0.5);
}
    
// Command list
void helperfunc()
{
    myPort.printf("\n");
    myPort.printf("*** Help List ***\n");
    myPort.printf("Enter \"r\" to use RGB sensor.\n");
    myPort.printf("Enter \"s\" to use distance sensor.\n");
    myPort.printf("Enter \"m\" to set the servos.\n");
    myPort.printf("Enter \"k\" to select the servo.\n");
    myPort.printf("Enter \"g\" to get the information from gate.\n");
    myPort.printf("Enter \"p\" to use the motors at the bottom.\n");
    myPort.printf("Enter \"d\" to read the distance from ultral sonic.\n");
    myPort.printf("Enter \"y\" to get the results of the color sensor array.\n");
    myPort.printf("Enter \"u\" to print the result of color sensors.\n");
    myPort.printf("Enter \"a\" to change state of gift gate.\n");
    myPort.printf("Enter \"c\" to control the mid motor.\n");
    myPort.printf("Enter \"e\" to control the top motor.\n");
    myPort.printf("Enter \"b\" to read the detector.\n");
    myPort.printf("Enter \"h\" to print the card infomation.\n");
    myPort.printf("Enter \"f\" to read the card.\n");
    myPort.printf("Enter \"t\" to move the pipe box.\n");
    myPort.printf("Enter \"i\" to move top motor.\n");
    myPort.printf("Advanced functions\n");
    myPort.printf("Enter \"o\" to initialize the map data.\n");
    myPort.printf("Enter \"z\" to get the results of the color sensor array.\n");
    myPort.printf("Enter \"x\" to compare the result.\n");
    myPort.printf("Enter \"v\" to compare the result.\n");
    myPort.printf("Enter \"q\" to quit.\n");
    myPort.printf("*****************\n");
}

void ReadDetector()
{
    myPort.printf("The state of the detector: ");
    int i = Detector;
    myPort.printf("%d\n", i);
}

// This function must be called before the game begin
void Initrgbs()
{
    colorsensor.enablePowerAndRGBC();
    colorsensor.setIntegrationTime(100);
    colorsensor2.enablePowerAndRGBC();
    colorsensor2.setIntegrationTime(100);
}

// The card has four pieces to read
// The degrees on the names are not the real 
// degress for servo0, the real degrees have
// been tested and changed on fpga
// Thus we only change the "state" of the FSM
void GetCardInformation()
{
    SelectServo(0);
    servo.Turn_0();
    wait(0.9);
    verifyarray[0] = ReadGate();
    wait(0.1);
    servo.Turn_30();
    wait(0.5);
    verifyarray[1] = ReadGate();
    wait(0.2);
    servo.Turn_60();
    wait(0.5);
    verifyarray[2] = ReadGate();
    wait(0.2);
    servo.Turn_90();
    wait(0.5);
    verifyarray[3] = ReadGate();
    wait(0.2);
    
}

void ControlTheMidMotor(int a)
{
    switch(a)
    {
        case 0: Charge2 = 0;
                Charge3 = 0; break;
        case 1: Charge2 = 1;
                Charge3 = 0;
                //wait(0.85);
                 break;
        case 2: Charge2 = 0;
                Charge3 = 1;
                //wait(0.8);
                 break;
        default:Charge2 = 0;
                Charge3 = 0; break;
    }
    wait(0.1);
    Charge2 = 0;
    Charge3 = 0;
}

void FuncControlTheMidMotor(int a)
{
    switch(a)
    {
        case 0: Charge2 = 0;
                Charge3 = 0; break;
        case 1: Charge2 = 1;
                Charge3 = 0;
                wait(0.90);
                 break;
        case 2: Charge2 = 0;
                Charge3 = 1;
                wait(0.88);
                 break;
        default:Charge2 = 0;
                Charge3 = 0; break;
    }
    //wait(0.1);
    Charge2 = 0;
    Charge3 = 0;
}

void ControlTheMidMotor()
{
    myPort.printf("Enter 0 to stop.\n");
    myPort.printf("Enter 1 to move forward.\n");
    myPort.printf("Enter 2 to move backward.\n");
    myPort.printf("Default: 0.\n");
    char a = myPort.getc();
    switch(a)
    {
        case '0': ControlTheMidMotor(0); break;
        case '1': ControlTheMidMotor(1); break;
        case '2': ControlTheMidMotor(2); break;
        default : ControlTheMidMotor(0); break;
    }
}

void FuncControlTheMidMotor()
{
    myPort.printf("Enter 0 to stop.\n");
    myPort.printf("Enter 1 to move forward.\n");
    myPort.printf("Enter 2 to move backward.\n");
    myPort.printf("Default: 0.\n");
    char a = myPort.getc();
    switch(a)
    {
        case '2': FuncControlTheMidMotor(2); break;
        case '1': FuncControlTheMidMotor(1); break;
        case '0': FuncControlTheMidMotor(0); break;
    }
}

void FuncControlTheMotor()
{
    myPort.printf("Enter 0 to stop.\n");
    myPort.printf("Enter 1 to move upward.\n");
    myPort.printf("Enter 2 to move downward.\n");
    myPort.printf("Default: 0.\n");
    char a = myPort.getc();
    switch(a)
    {
        case '1': FuncControlTheMotor(1); break;
        case '2': FuncControlTheMotor(2); break;
        case '0': FuncControlTheMotor(0); break;
    }
}

void FuncTopMotorUpSlow()
{
    for(int i = 0; i != 12; i++)
    {
        Charge0 = 1;
        Charge1 = 0;
        wait(0.2);
    
        Charge0 = 0;
        Charge1 = 0;
        wait(0.08);
    }
}
    
void FuncControlTheMotor(int a)
{
    switch(a)
    {
        case 0: Charge0 = 0;
                Charge1 = 0; break;
        case 1: Charge0 = 1;
                Charge1 = 0; 
                wait(2.36);
                break;
        case 2: Charge0 = 0;
                Charge1 = 1;
                
                while(Detector);
                wait(0.18);
                break;
        default:Charge0 = 0;
                Charge1 = 0; break;
    }
    Charge0 = 0;
    Charge1 = 0;
}

void ControlTheMotor(int a)
{
    switch(a)
    {
        case 0: Charge0 = 0;
                Charge1 = 0; break;
        case 1: Charge0 = 1;
                Charge1 = 0;
                break;
        case 2: Charge0 = 0;
                Charge1 = 1;
                break;
        default:Charge0 = 0;
                Charge1 = 0; break;
    }
    wait(0.1);
    Charge0 = 0;
    Charge1 = 0;
}

void PullUpAndRestore()
{
    FuncControlTheMidMotor(1);
    FuncTopMotorUpSlow();
}

void MoveDownTheTop()
{
    FuncControlTheMotor(2);
    FuncControlTheMidMotor(2);
}

void LightCharge()
{
    /*if(GateLight)
        GateLight = 0;
    else
        GateLight = 1;*/
        while(1)
        {
            GateLight = 1;
            wait(0.3);
            GateLight = 0;
            wait(0.3);
        }
}

void ControlTheMotor()
{
    myPort.printf("Enter 0 to stop.\n");
    myPort.printf("Enter 1 to move upward.\n");
    myPort.printf("Enter 2 to move downward.\n");
    myPort.printf("Default: 0.\n");
    char a = myPort.getc();
    switch(a)
    {
        case '0': ControlTheMotor(0); break;
        case '1': ControlTheMotor(1); break;
        case '2': ControlTheMotor(2); break;
        default: ControlTheMotor(0); break;
    }
    
}

void Gift()
{
    myPort.printf("Enter 0 to open the gate.\n");
    myPort.printf("Enter 1 to close the gate.\n");
    myPort.printf("Default: 1.\n");
    SelectServo(2);
    char a = myPort.getc();
    switch(a)
    {
        case '0': GiftGateOpen(); break;
        case '1': GiftGateClose(); break;
        default: GiftGateClose(); break;
    }
    
    
}

void GiftGateOpen()
{
    SelectServo(2);
    servo.Turn_90();
}

void GiftGateClose()
{
    SelectServo(2);
    servo.Turn_30();
}

void GetResult()
{
    // Change to servo1
    SelectServo(1);
    
    //
    //first cycle
    //
    servo.Turn_30();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    maparray[0] = rgbcharge.FindColorBeta(rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    maparray[4] = rgbcharge.FindColorBeta(rgb_readings2[1], rgb_readings2[2], rgb_readings2[3]);
    
    //
    //second cycle
    //
    servo.Turn_60();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    maparray[1] = rgbcharge.FindColorBeta(rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    maparray[5] = rgbcharge.FindColorBeta(rgb_readings2[1], rgb_readings2[2], rgb_readings2[3]);
    
    //
    //third cycle
    //
    servo.Turn_90();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    maparray[2] = rgbcharge.FindColorBeta(rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    maparray[6] = rgbcharge.FindColorBeta(rgb_readings2[1], rgb_readings2[2], rgb_readings2[3]);
    
    //
    //fourth cycle
    //
    servo.Turn_120();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    maparray[3] = rgbcharge.FindColorBeta(rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    maparray[7] = rgbcharge.FindColorBeta(rgb_readings2[1], rgb_readings2[2], rgb_readings2[3]);
    
}

void printTheArray()
{
    myPort.printf("The results are printed in inverse clock wise.\n");
    for(int i = 0; i != 8; i++)
        myPort.printf("%d\n", maparray[i]);
}

int ReadXred()
{
    return Xred;
}

void MotorFunc2()
{
    while(1)
    {
        motorCharge.LeftOn();
        wait_ms(700);
        motorCharge.RightOn();
        wait_ms(700);
    }
}

void MotorFunc()
{
    myPort.printf("Enter 0 to turn left on.\n");
    myPort.printf("Enter 1 to turn right on.\n");
    myPort.printf("Enter 2 to turn both on.\n");
    myPort.printf("Enter 3 to stop.\n");
    myPort.printf("Default: 3.\n");
    char c = myPort.getc();
    switch(c)
    {
        case '0':motorCharge.LeftOn(); break;
        case '1':motorCharge.RightOn(); break;
        case '2':motorCharge.StraightOn(); break;
        default: motorCharge.Stop(); break;
    }
}

void ReadUltralDistance()
{
    int temp1[3],temp2[3];
    for(int i = 0; i != 3; i++)
    {
        int temp = UltralSonicLeft.distance(CM);
        temp = temp == -1 ? 50: temp;
        temp1[i] = temp;
        temp = UltralSonicRight.distance(CM);
        temp = temp == -1 ? 50: temp;
        temp2[i] = temp;
    }
    
    UltralArray[0] = GetMean(temp1);
    UltralArray[1] = GetMean(temp2);
}

int GetMean(int* a)
{
    int temp = 0;
    for(int i = 0; i!= 3; i++)
    {
        temp += a[i];
    }
    
    return temp/3;
}

void UltalDistance()
{
    ReadUltralDistance();
    myPort.printf("The distance of left: %d\n", UltralArray[0]);
    myPort.printf("The distance of right: %d\n", UltralArray[1]);
}

void SelectServo()
{
    myPort.printf("Enter 0 to control the servo of card reading.\n");
    myPort.printf("Enter 1 to control the servo of color sensor.\n");
    myPort.printf("Enter 2 to control the servo of gift gate.\n");
    myPort.printf("Default: 0\n");
    char a = myPort.getc();
    switch(a)
    {
        case '0': SelectServo(0); break;
        case '1': SelectServo(1); break;
        case '2': SelectServo(2); break;
        default: SelectServo(0); break;
    }
    
}

int ReadGate()
{
    return OpticGate;
}

void GetGate()
{
    myPort.printf("%d\n", ReadGate());
}

void SelectServo(int n)
{
    if(n == 0)
    {
        ServoSelect1 = 0;
        ServoSelect0 = 0;
    }
    else if(n == 1)
    {
        ServoSelect1 = 0;
        ServoSelect0 = 1;
    }
    else if(n == 2)
    {
        ServoSelect1 = 1;
        ServoSelect0 = 1;
    }
}



//Trriger function when the command comes in
void CommandReceive ()
{
    for(int i = 0; i < 5; i++)
    {
        buffer[i] = myPort.getc();
    }
    CommandDeal(buffer);
}

//Deal with the command
void CommandDeal(char* buffer)
{
    if(Compare("rdist",buffer))
    {
        printf(buffer);
        distancesensorfunc();
    }
    else if(Compare("rrgbs",buffer))
    {
        printf(buffer);

        //rgbsensorfunc();
    }
    else if(Compare("servo",buffer))
    {
        printf(buffer);
        servo.Turn_0();
        wait(0.8);
        servo.Turn_90();
        wait(0.7);
        servo.Turn_180();
    }
    else if(Compare("mtest",buffer))
    {
      TurnToLogin();
    }
    else if(Compare("mgame",buffer))
    {
      TurnToGame();
    }
    else if(Compare("end__",buffer))
    {
        IsPlaying = false;
        IsEscape = true;
        //myPort.printf("end rec");
    }
    else if(Compare("begin",buffer))
    {
        FindingUser = false;
    }
    else if(Compare("dance",buffer))
    {
      IsTest = false;
    }
    else if(Compare("verif",buffer))
    {
      //printf("Get it\n");
      IsCardIn = true;
    }
    else if(Compare("compl",buffer))
    {
      IsFetched = true;
    }  
}

//Base funtion to compare the commands
bool Compare(char* var1, char* var2)
{
    for(int i = 0; i < 5; i++)
    {
        if(var1[i] == var2[i])
        continue;
        else
        return false;
    }
    
    return true;
}
///
/// Communicate to fpga and move servos
/// Use on serial port
///
void fpgafunc()
{
    myPort.printf("The FPGA can set the servo to 0(1), 30(2), 60(3), 90(4), 120(5), 150(6), 180(7), 45(8) degrees.\n");
    myPort.printf("Enter the number: defaule :(1)\n");
    char a = myPort.getc();
    switch(a)
    {
        case '1': servo.Turn_0(); break;
        case '2': servo.Turn_30(); break;
        case '3': servo.Turn_60(); break;
        case '4': servo.Turn_90(); break;
        case '5': servo.Turn_120(); break;
        case '6': servo.Turn_150(); break;
        case '7': servo.Turn_180(); break;
        case '8': servo.Turn_45(); break;
        default: servo.Turn_0(); break;
    }
    wait(0.5);
}

// Read rgb to the port
void rgbsensorfunc()
{
    colorsensor.enablePowerAndRGBC();
    colorsensor.setIntegrationTime(100);
    wait(0.1);
    int rgb_readings[4];
    //wait(0.5);
    colorsensor.getAllColors( rgb_readings );
    //myPort.printf( "red: %d, green: %d, blue: %d, clear: %d\n", rgb_readings[0], rgb_readings[1], rgb_readings[2], rgb_readings[3] );
    int red = rgb_readings[1]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    int green = rgb_readings[2]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    int blue = rgb_readings[3]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    myPort.printf("red: %d, green: %d, blue: %d\n",red,green,blue);
    myPort.printf("clear: %d\n",rgb_readings[0]);
    //colorsensor.disablePowerAndRGBC();
    colorsensor2.getAllColors( rgb_readings );
    //myPort.printf( "red: %d, green: %d, blue: %d, clear: %d\n", rgb_readings[0], rgb_readings[1], rgb_readings[2], rgb_readings[3] );
    red = rgb_readings[1]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    green = rgb_readings[2]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    blue = rgb_readings[3]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    myPort.printf("red: %d, green: %d, blue: %d\n",red,green,blue);
    myPort.printf("clear: %d\n",rgb_readings[0]);
}

//Read distance to the port
void distancesensorfunc()
{
    float reading;
    reading = rf;
    myPort.printf("Read %4.1f cm\n", reading);
}

// Deprecated
float ReadDistance()
{
   return rf;
   //return 0;
}

bool ReachToUser()
{
    int reading = rf;
    if(reading > 7)
    return true;
    else
    return false;
}
    
///
/// Complete the task:  1. read data from rgb sensor
///                     2. analyse the data and move servo to the right angles
///                     3. output message on port
///
void rgbTofpga()
{
    colorsensor.enablePowerAndRGBC();
    colorsensor.setIntegrationTime(100);
    int rgb_readings[4];
    colorsensor.getAllColors( rgb_readings );
    int color = rgbcharge.FindColor(rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    int red = rgb_readings[1]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    int green = rgb_readings[2]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    int blue = rgb_readings[3]*255/(rgb_readings[1]+rgb_readings[2]+rgb_readings[3]);
    myPort.printf("red: %d, green: %d, blue: %d\n",red,green,blue);
    
    switch(color)
    {
        case 1: servo.Turn_0(); break;
        case 2: servo.Turn_90(); break;
        case 3: servo.Turn_180(); break;
    }
}

void TurnToLogin()
{
    myPort.printf("dtolo");
}

void TurnToFirst()
{
    myPort.printf("frstp");
}

void TurnToGame()
{
    myPort.printf("login");
}

void TurnToDebug()
{
    myPort.printf("root_");
}

void Verifying()
{
    myPort.printf("verif");
}

void PCGameStart()
{
    myPort.printf("start");
}

void PCGameEnd()
{
    myPort.printf("end__");
}

void PCGamePause()
{
    myPort.printf("pause");
}

void PCOutRange()
{
    myPort.printf("outrn");
}

void PCComeBack()
{
    myPort.printf("gtbac");
}

void PCDisplayScreen()
{
    myPort.printf("displ");
}

// The box moves to the user, 
// When the user inserts the card,
// The Turn to Login Page and verify the card
void FindUser()
{
    __enable_irq();
    //TurnToFirst();
    wait(0.5);
    FindingUser = true;
    IsStaring = false;
    while(FindingUser)
    {
        wait(1);
        ReadUltralDistance();
        //Test();
        if(UltralArray[0] > 25L && UltralArray[1] > 25L)
        {
            if(IsStaring)
            continue;
            else
            {
                PCEyesMid();
                IsStaring = true;
                IsStaringLeft = false;
                IsStaringRight = false;
            }
        }
        else if(UltralArray[0] < 30L && UltralArray[1] < 30L)
        {
            if(IsStaring)
                continue;
            else
            {
                PCEyesMid();
                IsStaring = true;
                IsStaringLeft = false;
                IsStaringRight = false;
            }
        }
        else if(UltralArray[0] < 30L && UltralArray[1] > 30L && UltralArray[0] > 0)
        {
            if(IsStaringLeft)
                continue;
            else
            {
                PCEyesLeft();
                IsStaring = false;
                IsStaringLeft = true;
                IsStaringRight = false;
            }
        }
        else if(UltralArray[0] > 30L && UltralArray[1] < 30L && UltralArray[1] > 0)
        {
            if(IsStaringRight)
                continue;
            else
            {
                PCEyesRight();
                IsStaring = false;
                IsStaringLeft = false;
                IsStaringRight = true;
            }
        }
    }
}

void Test()
{
   
        motorCharge.StraightOn();
        if(Xred && ReadDistance() < 15)
        {
            motorCharge.Stop();
        }
        else if(UltralArray[0] < 20L && UltralArray[0] > 0)
        {
            motorCharge.LeftOn();
        }
        else if(UltralArray[1] < 20L && UltralArray[1] > 0)
        {
            motorCharge.RightOn();
        }
        
      
}

void TouchUser(){
    while(1)
    {
        if( ReadDistance() < 15)
        {
            TurnToGame();
            wait(2);
            PlayGame();
            break;
        }
    }
}

// The card contains the message of whether it is the user or the operator
bool Identification()
{ 
    IsCardIn = false;
    __enable_irq();
    while(!IsCardIn)
    {
        GateLight = 1;
        wait(0.1);
        GateLight = 0;
        wait(0.1);
    }
    //wait(0.5);
    Verifying();
    GetCardInformation();
    GateLight = 0;
    if(DecideWho() < 15)
        return true;
    return false;
}

int DecideWho()
{
    int number = 0;
    return number = 8 * verifyarray[3] + 4 * verifyarray[2] + 2 * verifyarray[1] + 1 * verifyarray[0];
}

void Preparing()
{
    MoveDownTheTop();
    // PC changes to game page
    TurnToGame();
    wait(1.3);
    // If there are five maps
    int randomnumber = rand() % 5;
    
    // Set the array
    switch(randomnumber)
    {
        case 0: CopyArrayData(Map01); myPort.printf("mp000"); break;
        case 1: CopyArrayData(Map01); myPort.printf("mp000"); break;
        case 2: CopyArrayData(Map01); myPort.printf("mp000"); break;
        case 3: CopyArrayData(Map01); myPort.printf("mp000"); break;
        case 4: CopyArrayData(Map01); myPort.printf("mp000"); break;
        default: CopyArrayData(Map01); myPort.printf("mp000"); break;
    }
    
    mapnumber = 1;
    
    wait(0.5);
}

// Copy the data of the specific map to the correctarray
void CopyArrayData(int * a)
{
    for(int i = 0; i != 8; i++)
    {
        correctarray[i] = a[i];
    }
}

void GameStart()
{
    
}

void PlayGame(){
    
    __disable_irq();
    //myPort.printf("start");
    char a = myPort.getc();
    //int GameStatus = 1;
    bool IsOutOfRange = false;
    __enable_irq();
    IsPlaying = true;
    IsEscape = false;
    while(IsPlaying)
    {
        wait(0.1);
        if(ReachToUser())
        {
            if(!IsOutOfRange)
            continue;
            IsOutOfRange = false;
            myPort.printf("gtbac");
            wait(0.3);
        }
        else
        {
            if(IsOutOfRange)
            continue;
            IsOutOfRange = true;
            myPort.printf("outrn");
            wait(0.3);
        }
        
    }
    __disable_irq();
}
    
bool GameEnd()
{
    wait(0.2);
    myPort.printf("gtbac");
    wait(0.1);
    PCGameEnd();
    GetResultBeta();
    if(CompareResult())
    {
        PCGameSucceed();
        wait(5);
        return true;
    }
    else
    {
        PCGameFailed();
        wait(5);
        return false;
    }
    
}

bool CompareResult()
{
    /* First edition */
    /*
    for(int i = 0; i != 8; i++)
    {
        if(maparray[i] != correctarray[i])
            return false;
    }
    
    return true;
    */
    /* First edition */
    
    return GetDecide(mapnumber) ? true : false;
}

void Reward()
{
    IsFetched = false;
    GiftGateOpen();
    __enable_irq();
    while(!IsFetched)
    {
        GateLight = 1;
        wait(0.5);
        GateLight = 0;
        wait(0.5);
    }
    __disable_irq();
    GiftGateClose();
}

void PCEyesMid() { myPort.printf("plmid"); }
void PCEyesLeft() { myPort.printf("pllft"); }
void PCEyesRight() { myPort.printf("plrit"); }
void PCEyesPause() { myPort.printf("pauan"); }
void PCEyesPlay() { myPort.printf("plyan"); }
void PCEyesStop() { myPort.printf("stpan"); }
void PCGameSucceed() { myPort.printf("gmsuc"); }
void PCGameFailed() { myPort.printf("gmfal"); }

void Reset()
{
    PullUpAndRestore();
    wait(1);
}

void GameLogicControl()
{
    while(1)
    {
        wait(1);
        TurnToFirst();
        FindUser();
        if(!Identification())
        {
            __disable_irq();
            TurnToDebug();
            wait(0.5);
            doumo();
            continue;
        }
        Preparing();
        GameStart();
        PlayGame();
        if(IsEscape)
        {
            Reset();
            continue;
        }
        if(GameEnd())
        {
            Reward();
        }
        
        Reset();
    }
}
        
void InitializergbData()
{
    printf("\n Now enter the map number (1 - 5): ");
    char a = myPort.getc();
    switch(a)
    {
        case '1': InitializergbData(1); break;
        case '2': InitializergbData(1); break;
        case '3': InitializergbData(1); break;
        case '4': InitializergbData(1); break;
        case '5': InitializergbData(1); break;
        default: InitializergbData(1); break;
    }
}

void InitializergbData(int mapnumber)
{
    // Change to servo1
    SelectServo(1);
    
    //
    //first cycle
    //
    servo.Turn_30();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    rgbcharge.GetMapData(0, rgb_readings[1], rgb_readings[2], rgb_readings[3], 1, mapnumber);
    rgbcharge.GetMapData(4, rgb_readings[1], rgb_readings[2], rgb_readings[3], 1, mapnumber);
       
    //
    //second cycle
    //
    servo.Turn_60();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    rgbcharge.GetMapData(1, rgb_readings[1], rgb_readings[2], rgb_readings[3], 1, mapnumber);
    rgbcharge.GetMapData(5, rgb_readings[1], rgb_readings[2], rgb_readings[3], 1, mapnumber);
        
    //
    //third cycle
    //
    servo.Turn_90();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    rgbcharge.GetMapData(2, rgb_readings[1], rgb_readings[2], rgb_readings[3], 1, mapnumber);
    rgbcharge.GetMapData(6, rgb_readings[1], rgb_readings[2], rgb_readings[3], 1, mapnumber);
        
    //
    //fourth cycle
    //
    servo.Turn_120();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    rgbcharge.GetMapData(3, rgb_readings[1], rgb_readings[2], rgb_readings[3], 1, mapnumber);
    rgbcharge.GetMapData(7, rgb_readings[1], rgb_readings[2], rgb_readings[3], 1, mapnumber);
    
}

void GetResultBeta()
{
    // Change to servo1
    SelectServo(1);
    
    //
    //first cycle
    //
    servo.Turn_30();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    rgbcharge.ReadInData(0, rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    rgbcharge.ReadInData(4, rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    
    //
    //second cycle
    //
    servo.Turn_60();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    rgbcharge.ReadInData(1, rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    rgbcharge.ReadInData(5, rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    
    //
    //third cycle
    //
    servo.Turn_90();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    rgbcharge.ReadInData(2, rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    rgbcharge.ReadInData(6, rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    
    //
    //fourth cycle
    //
    servo.Turn_120();
    wait(1);
    //Read colors
    do{
    colorsensor.getAllColors( rgb_readings );
    }while(rgb_readings[1] == 0 || rgb_readings[2] == 0 || rgb_readings[3] == 0);
    do{
    colorsensor2.getAllColors( rgb_readings2 );}
    while(rgb_readings2[1] == 0 || rgb_readings2[2] == 0 || rgb_readings2[3] == 0);
    wait(0.4);
    // Store results
    rgbcharge.ReadInData(3, rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    rgbcharge.ReadInData(7, rgb_readings[1], rgb_readings[2], rgb_readings[3]);
    
}

void GetTheDecide()
{
    if(rgbcharge.Decide(1))
        printf("\n True");
    else
        printf("\n False");
}

bool GetDecide(int mapnumber)
{
    return rgbcharge.Decide(mapnumber) ? true : false;
}