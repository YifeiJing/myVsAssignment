#include "ServoCharge.h"
#include "mbed.h"

///
/// This class is the control of the servos on fpga
/// para: s1, s2, s3 <PinName> three digitalout pins on chip
///
ServoCharge::ServoCharge(PinName s1, PinName s2, PinName s3):sel_1(s1,0),sel_2(s2,0),sel_3(s3,0)
{}

///
/// Instance functions control on angles
///
void ServoCharge::Turn_0()
{
    
    sel_1 = 0;
    sel_2 = 0;
    sel_3 = 0;
}

void ServoCharge::Turn_30()
{
    sel_1 = 0;
    sel_2 = 0;
    sel_3 = 1;

}

void ServoCharge::Turn_60()
{
    sel_1 = 0;
    sel_2 = 1;
    sel_3 = 0;
}

void ServoCharge::Turn_90()
{
    sel_1 = 0;
    sel_2 = 1;
    sel_3 = 1;
}

void ServoCharge::Turn_120()
{
    sel_1 = 1;
    sel_2 = 0;
    sel_3 = 0;
}

void ServoCharge::Turn_150()
{
    sel_1 = 1;
    sel_2 = 0;
    sel_3 = 1;
}

void ServoCharge::Turn_180()
{
    sel_1 = 1;
    sel_2 = 1;
    sel_3 = 0;
}

void ServoCharge::Turn_45()
{
    sel_1 = 1;
    sel_2 = 1;
    sel_3 = 1;
}